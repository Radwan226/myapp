import os
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock
from threading import Thread
import yt_dlp

# مسار الحفظ (Downloads في الأندرويد)
DOWNLOAD_PATH = "/sdcard/Download"

# القيم للجودات
QUALITY_MAP = {
    "فيديو 240p": "bestvideo[height=240]+bestaudio/best[height=240]",
    "فيديو 360p": "bestvideo[height=360]+bestaudio/best[height=360]",
    "فيديو 480p": "bestvideo[height=480]+bestaudio/best[height=480]",
    "فيديو 720p": "bestvideo[height=720]+bestaudio/best[height=720]",
    "فيديو 1080p": "bestvideo[height=1080]+bestaudio/best[height=1080]",
    "صوت MP3": "bestaudio/best"
}

class YouTubeDownloader(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(orientation="vertical", padding=10, spacing=10, **kwargs)

        self.add_widget(Label(text="📥 رابط فيديو YouTube:", font_size=18))
        self.url_input = TextInput(hint_text="أدخل الرابط هنا", multiline=False)
        self.add_widget(self.url_input)

        self.add_widget(Label(text="🎯 اختر الجودة:", font_size=18))
        self.quality_spinner = Spinner(
            text="فيديو 720p",
            values=list(QUALITY_MAP.keys()),
            size_hint=(1, None),
            height=50
        )
        self.add_widget(self.quality_spinner)

        self.status_label = Label(text="", font_size=16)
        self.add_widget(self.status_label)

        self.download_btn = Button(text="⬇ تحميل", size_hint=(1, None), height=50)
        self.download_btn.bind(on_press=self.start_download)
        self.add_widget(self.download_btn)

    def start_download(self, instance):
        url = self.url_input.text.strip()
        if not url:
            self.update_status("❌ من فضلك أدخل رابط صحيح")
            return

        quality = self.quality_spinner.text
        self.update_status("⏳ جاري التحميل...")
        Thread(target=self.download_video, args=(url, quality)).start()

    def download_video(self, url, quality):
        try:
            ydl_opts = {
                'outtmpl': os.path.join(DOWNLOAD_PATH, '%(title)s.%(ext)s'),
                'quiet': True,
                'format': QUALITY_MAP[quality],
            }

            # لو اختار MP3 أضيف تحويل
            if quality == "صوت MP3":
                ydl_opts['postprocessors'] = [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '192',
                }]

            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])

            Clock.schedule_once(lambda dt: self.update_status("✅ تم التحميل! الملف في مجلد التنزيلات"))

        except Exception as e:
            Clock.schedule_once(lambda dt: self.update_status(f"❌ خطأ: {str(e)}"))

    def update_status(self, message):
        self.status_label.text = message


class YouTubeDownloaderApp(App):
    def build(self):
        return YouTubeDownloader()


if __name__ == '__main__':
    YouTubeDownloaderApp().run()